<?php
/**
 * The primary sidebar is set in the sidebar-primary.php so that we can have control over the layout. Do
 * not overwrite this file.
 *
 * @author Beans
 * @link   http://www.getbeans.io
 */

<?php
/**
 * This file content is situated in /lib/templates/structure/comments.php and should
 * strictly be overwritten via your child theme.
 *
 * We strongly recommend to read Beans documentation to find out more how to
 * customize Beans theme.
 *
 * @author Beans
 * @link   http://www.getbeans.io
 */

// Template situated in /lib/templates/structure/comments.php
beans_load_default_template( __FILE__ );

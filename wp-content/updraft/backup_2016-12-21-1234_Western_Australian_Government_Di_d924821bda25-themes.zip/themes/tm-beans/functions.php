<?php
/**
 * Initialize Beans theme framework.
 *
 * @author Beans
 * @link   http://www.getbeans.io
 */

require_once( dirname( __FILE__ ) . '/lib/init.php' );

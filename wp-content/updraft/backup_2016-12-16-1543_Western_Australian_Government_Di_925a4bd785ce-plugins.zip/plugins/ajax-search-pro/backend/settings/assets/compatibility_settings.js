// Simulate a click on the first element to initialize the tabs
jQuery(function ($) {
    $('.tabs a[tabid=1]').click();
});